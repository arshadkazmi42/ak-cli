### Pull the changes from repository

`git pull {{REMOTE}} {{BRANCH}}`

- <b>REMOTE: </b> The remote handle
- <b>BRANCH: </b> A branch from remote repository

#### Example:

`git pull origin master`
