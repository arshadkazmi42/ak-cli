# SCP :cyclone:
Daily used scp commands

- [Copy from local to server](scp-local-to-server.md)
- [Copy from server to local](scp-server-to-local.md)