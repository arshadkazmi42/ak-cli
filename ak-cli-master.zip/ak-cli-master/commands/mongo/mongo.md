# Mongo :shell:
Daily used mongo commands

- [Dump collection from mongoDB](mongo-dump-collection.md)
- [Restore collection to mongoDB](mongo-restore-collection.md)